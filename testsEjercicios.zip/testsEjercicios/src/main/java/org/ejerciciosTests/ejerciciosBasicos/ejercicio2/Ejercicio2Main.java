package org.ejerciciosTests.ejerciciosBasicos.ejercicio2;

import static java.lang.String.valueOf;

public class Ejercicio2Main {

	public static void main(String[] args) {
		/*
		 * Programa Java que muestre todos los valores de un contador de 5 dígitos empezando por 00000
		 * y acabando en 99999 con la particularidad que cada vez que se deba mostrar un 3 se muestre E.
		 */
		String numero;

		for (int i = 0; i < 100000; i++) {
			numero = valueOf(i);
			if (numero.length() < 5) {
				if (numero.length() < 2) {
					numero = "0000" + numero;
				} else if (numero.length() < 3) {
					numero = "000" + numero;
				} else if (numero.length() < 4) {
					numero = "00" + numero;
				} else {
					numero = "0" + numero;
				}
			}
			numero = reemplazar3porE(numero);
			System.out.println(numero);
		}
	}

	/**
	 * Reemplaza los 3 por E
	 * @param numero String
	 * @return número con los 3 reemplazados por E
	 */
	public static String reemplazar3porE( String numero) {
		numero = numero.replace("3", "E");
		return numero;
	}
}
