package org.ejerciciosTests.ejerciciosStreams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.ejerciciosTests.ejerciciosStreams.Utils.*;


public class Main {
	public static void main(String[] args) {

		System.out.println("-------- EJ 1 ----------");


//		1.	Filtrar los elementos divisibles por algún número específico que oscila entre 0 y 10.

//		Lista de números a dividir
		List<Integer> numbers = Arrays.asList(
				0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
		);

		divisibles(numbers, 0, 1);

		System.out.println("\n-------- EJ 2 ----------");

//		2.	Filtrar los elementos con una letra mayúscula en cualquier índice específico.

		List<String> words = new ArrayList<>();
		words.add("Primeros");
		words.add("Otra");
		words.add("sEgundos");
		words.add("teRceros");
		words.add("cuaRtos");
		words.add("quinTos");
		words.add("sextoS");

		System.out.println("Las palabras con la letra mayúscula en el índice 0 son: ");

		System.out.println(maysEnIndice(words, 0));

		System.out.println("\n-------- EJ 3 ----------");

//	3.	Filtrado de los elementos que terminan con letras alfabéticas personalizadas.

//		Añado algunas palabras a la lista que terminen de forma diferente entre ellas
		words.add("Cualquier");
		words.add("Javier");
		words.add("Curto");
		words.add("Brull");

		System.out.println(endsWith(words, "rto"));

		System.out.println("\n-------- EJ 4 ----------");

//		Ejercicios con la clase Curso

		List<Curso> cursos = new ArrayList<>();
		cursos.add(new Curso("Curso profesional de Java", 6.5f, 50, 200));
		cursos.add(new Curso("Curso profesional de Python", 8.5f, 60, 800));
		cursos.add(new Curso("Curso profesional de DB", 4.5f, 70, 700));
		cursos.add(new Curso("Curso profesional de Android", 7.5f, 10, 400));
		cursos.add(new Curso("Curso profesional de Escritura", 1.5f, 10, 300));

//		•	Obtener la cantidad de cursos con una duración mayor a 5 horas.

		recuentoCursosMayorA(cursos, 5);

		System.out.println("\n-------- EJ 5 ----------");


//		•	Obtener la cantidad de cursos con una duración menor a 2 horas.

		recuentoCursosMenorA(cursos, 2);

		System.out.println("\n-------- EJ 6 ----------");


//		•	Listar el título de todos aquellos cursos con una cantidad de vídeos mayor a 50.

		System.out.println("Los cursos con más de 50 videos son los siguientes:");
		tituloMasDeXVideos(cursos, 50);

		System.out.println("\n-------- EJ 7 ----------");


//		•	Mostrar en consola el título de los 3 cursos con mayor duración.

		System.out.println(tituloMayorDuracion(cursos, 3));

		System.out.println("\n-------- EJ 8 ----------");

//		•	Mostrar en consola la duración total de todos los cursos.

		totalDuracion(cursos);

		System.out.println("\n-------- EJ 9 ----------");

//		•	Mostrar en consola todos aquellos cursos que superen el promedio en cuanto a duración se refiere.

		Double prom = promedio(cursos);
		System.out.println("Promedio de duración de los cursos: " + prom);

//		Cursos que superen el promedio
		superanProm(cursos, prom);

		System.out.println("\n-------- EJ 10 ----------");

//		•	Mostrar en consola la duración de todos aquellos cursos que tengan una cantidad de alumnos inscritos menor a 500.

		System.out.println("Los cursos con menos de 500 alumnos son los siguientes:");
		menosDeXAlumnos(cursos, 500);

		System.out.println("\n-------- EJ 11 ----------");

//		•	Obtener el curso con mayor duración.

		System.out.println("El curso con mayor duración es: ");
		System.out.println(tituloMayorDuracion(cursos, 1));

		System.out.println("\n-------- EJ 12 ----------");

//		•	Crear una lista de Strings con todos los títulos de los cursos.

		System.out.println("Títulos de todos los cursos:");
		listaTitulos(cursos);
	}
}