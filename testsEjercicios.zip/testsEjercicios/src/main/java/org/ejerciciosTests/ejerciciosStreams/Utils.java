package org.ejerciciosTests.ejerciciosStreams;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

class Utils {

	/**
	 * Devuelve los números divisibles entre el divisor
	 *
	 * @param numbers lista de números
	 * @param start   indice de inicio
	 * @param end     indice de fin
	 */
	public static void divisibles(List<Integer> numbers, int start, int end) {
		int value = numRandom(start, end);
		System.out.println("El valor aleatorio es: " + value);
		if (value == 0) {
			System.out.println("No se puede dividir por 0");
		} else {
			System.out.println("Los números divisibles por " + value + " son los siguientes:");
			numbers.stream()
					.filter(num -> num % value == 0)
					.forEach(System.out::println);
		}
	}

	/**
	 * Devuelve la palabra con la letra index en mayúscula
	 *
	 * @param words Lista de palabras
	 * @param index Índice de la letra en mayúscula
	 * @return
	 */
	public static List<String> maysEnIndice(List<String> words, int index) {
		return words.stream()
				.filter(word -> Character.isUpperCase(word.charAt(index)))
				.collect(Collectors.toCollection(ArrayList::new));
	}

	/**
	 * Devuelve las palabras que terminan de la forma indicada
	 *
	 * @param words Lista de palabras
	 * @param ends  Con qué terminan las palabras
	 * @return Lista de palabras que terminan con ends
	 */
	public static List<String> endsWith(List<String> words, String ends) {
		System.out.println("Las palabras que terminan en '" + ends + "' son las siguientes:");
		return words.stream()
				.filter(word -> word.endsWith(ends))
				.collect(Collectors.toCollection(ArrayList::new));
	}

	/**
	 * Devuelve el número de cursos con duración mayor a la indicada
	 *
	 * @param cursos   Lista de cursos
	 * @param duracion Duración mínima
	 * @return Número de cursos con duración mayor a la indicada
	 */
	public static int recuentoCursosMayorA(List<Curso> cursos, int duracion) {
		int count = (int) cursos.stream()
				.filter(curso -> curso.getDuracion() > duracion)
				.count();
		System.out.println("Total de cursos de más de " + duracion + " horas = " + count);
		return count;
	}

	/**
	 * Devuelve el número de cursos con duración menor a la indicada
	 *
	 * @param cursos   Lista de cursos
	 * @param duracion Duración máxima
	 * @return Número de cursos con duración menor a la indicada
	 */
	public static int recuentoCursosMenorA(List<Curso> cursos, int duracion) {
		int count = (int) cursos.stream()
				.filter(curso -> curso.getDuracion() < duracion)
				.count();
		System.out.println("Total de cursos de menos de " + duracion + " horas = " + count);
		return count;
	}

	/**
	 * Devuelve el título de los cursos con más de N videos
	 *
	 * @param cursos Lista de cursos
	 * @param videos Número de videos
	 * @return
	 */
	public static ArrayList<Curso> tituloMasDeXVideos(List<Curso> cursos, int videos) {
		ArrayList<Curso> newList = cursos.stream()
				.filter(curso -> curso.getVideos() > videos)
				.collect(Collectors.toCollection(ArrayList::new));
		newList.forEach(curso -> System.out.println(curso.getTitulo()));
		return newList;
	}

	/**
	 * Devuelve el título de mayor duración
	 *
	 * @param cursos Lista de cursos
	 * @param size   tamaño de la lista
	 * @return Título de mayor duración
	 */
	public static String tituloMayorDuracion(List<Curso> cursos, int size) {
		return cursos.stream()
				.sorted((dur1, dur2) -> Float.compare(dur2.getDuracion(), dur1.getDuracion()))
				.limit(size)
				.map(Curso::getTitulo)
				.collect(Collectors.joining("\n"));
	}

	/**
	 * Devuelve la duración total de los cursos
	 *
	 * @param cursos Lista de cursos
	 */
	public static double totalDuracion(List<Curso> cursos) {
		double dur = cursos.stream()
				.mapToDouble(Curso::getDuracion)
				.sum();
		System.out.println("La duración total de los cursos es de " + dur + " horas");
		return dur;
	}

	/**
	 * Devuelve el promedio de duración de los cursos
	 *
	 * @param cursos Lista de cursos
	 * @return Promedio de duración de los cursos
	 */
	public static Double promedio(List<Curso> cursos) {
		return cursos.stream()
				.mapToDouble(Curso::getDuracion)
				.average()
				.getAsDouble();
	}

	/**
	 * Devuelve los cursos con duración mayor al promedio
	 *
	 * @param cursos Lista de cursos
	 * @param avg    Promedio de duración de los cursos
	 */
	public static List<Curso> superanProm(List<Curso> cursos, double avg) {
		List<Curso> newList = cursos.stream()
				.filter(curso -> curso.getDuracion() > avg)
				.collect(Collectors.toCollection(ArrayList::new));

		newList.forEach(curso -> System.out.println("El \""
				+ curso.getTitulo()
				+ "\" con una duración de "
				+ curso.getDuracion()
				+ " supera el promedio"));
		return newList;
	}

	/**
	 * Devuelve los cursos con menos alumnos de los indicados
	 *
	 * @param cursos Lista de cursos
	 * @param alumn  Alumnos mínimos
	 */
	public static List<Curso> menosDeXAlumnos(List<Curso> cursos, int alumn) {
		List<Curso> newList = cursos.stream()
				.filter(curso -> curso.getAlumnos() < alumn)
				.collect(Collectors.toCollection(ArrayList::new));

		newList.forEach(curso -> System.out.println("El \""
				+ curso.getTitulo()
				+ "\" con una duración de "
				+ curso.getDuracion()
				+ " horas tiene " + curso.getAlumnos()
				+ " alumnos"));
		return newList;
	}

	/**
	 * Devuelve los títulos de todos los cursos
	 *
	 * @param cursos Lista de cursos
	 */
	public static List<String> listaTitulos(List<Curso> cursos) {
		List<String> titles =
				cursos.stream()
						.map(Curso::getTitulo)
						.collect(Collectors.toList());
		titles.forEach(title -> {
			int ind = titles.indexOf(title);
			System.out.println(ind + 1 + ". " + title);
		});
		return titles;
	}

	/**
	 * Generador de número aleatorio entre 2 valores
	 *
	 * @param min Valor mínimo
	 * @param max Valor máximo
	 * @return num aleatorio
	 */
	public static int numRandom(int min, int max) {
		Random random = new Random();
		return random.nextInt(max + min) + min;
	}
}
