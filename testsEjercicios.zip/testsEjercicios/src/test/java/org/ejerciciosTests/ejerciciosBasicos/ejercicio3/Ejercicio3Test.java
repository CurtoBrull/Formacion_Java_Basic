package org.ejerciciosTests.ejerciciosBasicos.ejercicio3;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.ejerciciosTests.ejerciciosBasicos.ejercicio3.Ejercicio3Main.cadenaMasLarga;
import static org.junit.jupiter.api.Assertions.*;

class Ejercicio3Test {

	@Test
	void cadena_mas_larga() {
		String cadena1 = "Texto largo";
		String cadena2 = "Texto";
		ArrayList<String> arr = new ArrayList<>(
				List.of(cadena1, cadena2)
		);
		assertEquals(cadena1, cadenaMasLarga(arr));
	}
}