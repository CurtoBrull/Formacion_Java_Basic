package org.ejerciciosTests.ejerciciosBasicos.ejercicio2;

import org.junit.jupiter.api.Test;

import static org.ejerciciosTests.ejerciciosBasicos.ejercicio2.Ejercicio2Main.*;
import static org.junit.jupiter.api.Assertions.*;

class Ejercicio2Test {

	@Test
	void reemplazar_3_por_E() {
		String numero = "13331";
		String resultado = reemplazar3porE(numero);
		assertEquals("1EEE1", resultado);
	}
}