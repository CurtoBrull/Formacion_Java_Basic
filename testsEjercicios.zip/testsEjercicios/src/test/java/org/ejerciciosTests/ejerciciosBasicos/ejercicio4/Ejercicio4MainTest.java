package org.ejerciciosTests.ejerciciosBasicos.ejercicio4;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.ejerciciosTests.ejerciciosBasicos.ejercicio4.Ejercicio4Main.*;
import static org.junit.jupiter.api.Assertions.*;

class Ejercicio4MainTest {

	Coche coche1 = new Coche("Seat", "Ibiza", 10000);
	Coche coche2 = new Coche("Seat", "Leon", 20000);
	ArrayList<Coche> listaCoches = new ArrayList<>(
			List.of(coche1, coche2)
	);

	@Test
	void coches_ordenados_menor_a_mayor() {
		cochesOrdenados(listaCoches);
		assertEquals(coche1, listaCoches.get(0));
	}

	@Test
	void coche_con_menor_numero_km() {
		masKilometros(listaCoches);
		assertEquals(coche1, listaCoches.get(0));
	}

	@Test
	void coche_con_km_maximos() {
		maxKilometros(listaCoches, 15000);
		assertEquals(coche1, listaCoches.get(0));
	}
}