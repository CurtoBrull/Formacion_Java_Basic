package org.ejerciciosTests.ejerciciosBasicos.ejercicio1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AlumnosTest {

	static Alumnos alumno;
	static Alumnos alumno2;

	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
		alumno = new Alumnos("Pepe", 5, 6, 7);
		alumno2 = new Alumnos("Juan", 5.5, 6.0, 7.3);
	}

	@Test
	void obtener_media_notas() {
		assertEquals(6, alumno.getMedia());
		assertEquals(6.266666666666667, alumno2.getMedia(), 0.01);
	}

	@Test
	void obtener_nota_mayor() {
		assertEquals(7, alumno.getMayor());
		assertEquals(7.3, alumno2.getMayor());
	}

	@Test
	void obtener_nota_menor() {
		assertEquals(5, alumno.getMenor());
		assertEquals(5.5, alumno2.getMenor());
	}
}