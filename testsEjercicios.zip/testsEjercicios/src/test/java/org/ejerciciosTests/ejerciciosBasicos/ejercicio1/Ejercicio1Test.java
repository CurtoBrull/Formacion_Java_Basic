package org.ejerciciosTests.ejerciciosBasicos.ejercicio1;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio1Test {

	static Alumnos alumno;
	static Alumnos alumno2;
	static Alumnos alumno3;

	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
		alumno = new Alumnos("Pepe", 5, 6, 7);
		alumno2 = new Alumnos("Juan", 5.5, 6.0, 7.3);
		alumno3 = new Alumnos("Pedro", 6.4, 7.0, 8.7);
	}

	@Test
	void obtener_media_notas() {
		assertEquals(6, alumno.getMedia());
		assertEquals(6.266666666666667, alumno2.getMedia(), 0.01);
		assertEquals(7.033333333333333, alumno3.getMedia(), 0.01);
	}
}