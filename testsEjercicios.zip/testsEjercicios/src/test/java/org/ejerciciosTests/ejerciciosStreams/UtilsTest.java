package org.ejerciciosTests.ejerciciosStreams;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import static org.junit.jupiter.api.Assertions.*;

class UtilsTest {

	static int random;
	static List<Integer> numbers;
	static List<String> words;
	static List<Curso> cursos;

	static int expected, actual;

	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
		random = Utils.numRandom(1,5);
		numbers = Arrays.asList(
				0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
		);
		words = Arrays.asList(
				"Primeros",
				"sEgundos",
				"Curto",
				"Harto"
		);

		cursos = new ArrayList<>();
		cursos.add(new Curso("Curso profesional de Java", 6.5f, 50, 200));
		cursos.add(new Curso("Curso profesional de Python", 8.5f, 60, 800));
	}

	@Test
	void divisibles() {
		numbers.stream().filter(n -> n % 5 == 0);
		assertEquals(0, numbers.get(0) % 5);
	}

	@Test
	void divisible_por_cero(){
//		El método está hecho con un random que solo admite valores positivos
		assertThrows(
				IllegalArgumentException.class,
				() -> Utils.divisibles(numbers, 0, 0));
	}

	@Test
	void palabras_mays_en_indice() {
		List<String> expected = List.of("sEgundos");
		List<String> actual = Utils.maysEnIndice(words, 1);
		assertEquals(expected, actual);
	}

	@Test
	void palabras_terminadas_en() {
		List<String> expected = List.of("Curto", "Harto");
		List<String> actual = Utils.endsWith(words, "rto");
		assertEquals(expected, actual);
	}

	@Test
	void total_cursos_duracion_mayor_a() {
		expected = 1;
		actual = Utils.recuentoCursosMayorA(cursos, 7);
		assertEquals(expected, actual);
	}

	@Test
	void total_cursos_duracion_menor_a() {
		expected = 2;
		actual = Utils.recuentoCursosMenorA(cursos, 9);
		assertEquals(expected, actual);
	}

	@Test
	void titulo_cursos_mas_de_N_videos() {
		List<Curso> expected = cursos;
		List<Curso> actual = Utils.tituloMasDeXVideos(cursos, 1);
		assertEquals(expected, actual);
	}

	@Test
	void tituloMayorDuracion() {
		String expected = "Curso profesional de Python\nCurso profesional de Java";
		String actual = Utils.tituloMayorDuracion(cursos, 2);
		assertEquals(expected, actual);
	}

	@Test
	void totalDuracion() {
		double expected = 15;
		double actual = Utils.totalDuracion(cursos);
		assertEquals(expected, actual);
	}

	@Test
	void promedio() {
		double expected = 7.5;
		double actual = Utils.promedio(cursos);
		assertEquals(expected, actual);
	}

	@Test
	void superanProm() {
		List<Curso> expected = List.of(cursos.get(1));
		List<Curso> actual = Utils.superanProm(cursos, 7.5);
		assertEquals(expected, actual);
	}

	@Test
	void menosDeXAlumnos() {
		List<Curso> expected = List.of(cursos.get(0));
		List<Curso> actual = Utils.menosDeXAlumnos(cursos, 500);
		assertEquals(expected, actual);
	}

	@Test
	void listaTitulos() {
		List<String> titles = List.of(cursos.get(0).getTitulo(), cursos.get(1).getTitulo());
		List<String> actual = Utils.listaTitulos(cursos);
		assertEquals(titles, actual);
	}
}