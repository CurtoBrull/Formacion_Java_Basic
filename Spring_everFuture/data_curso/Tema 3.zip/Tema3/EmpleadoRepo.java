package com.everis.repository;

public interface EmpleadoRepo {
	public void registrar (String nombre);
}
