package com.everis.repository.impl;

import com.everis.repository.EmpleadoRepo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class EmpleadoRepoImpl implements EmpleadoRepo {

	private static Logger LOG = LoggerFactory.getLogger(EmpleadoRepoImpl.class);
	
	@Override
	public void registrar(String nombre) {
		 LOG.info("Se ha saludado al empleado: "+nombre);
		
	}

}
