package com.everis.service;

public interface EmpleadoService {
	public void registrar (String name);
}
